<?php
/**
 * @author Presta-Module.com <support@presta-module.com>
 * @copyright Presta-Module
 * @license   see file: LICENSE.txt
 *
 *           ____     __  __
 *          |  _ \   |  \/  |
 *          | |_) |  | |\/| |
 *          |  __/   | |  | |
 *          |_|      |_|  |_|
 *
 ****/

if (!defined('_PS_VERSION_')) {
    exit;
}
function upgrade_module_2_1_0($module)
{
    if (!Configuration::getGlobalValue('PM_SPA_SECURE_KEY')) {
        Configuration::updateGlobalValue('PM_SPA_SECURE_KEY', Tools::strtoupper(Tools::passwdGen(16)));
    }
    return true;
}
