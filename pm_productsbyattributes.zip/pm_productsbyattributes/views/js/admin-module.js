var currentColorPicker = false;
$(document).ready(function() {
    $('div#addons-rating-container p.dismiss a').click(function() {
        $('div#addons-rating-container').hide(500);
        $.ajax({ type: "GET", url: window.location + '&dismissRating=1' });
        return false;
    });

    $('a.list-group-item').click(function() {
        $('a.list-group-item').removeClass('active');
        $(this).addClass('active');
        $('input[name=selected_tab]').val($(this).data('identifier'));
    });

    handleSelectedGroupOption();
    handleChangeProductNameOption();
    handleCategoryRestrictionOption();
    handleShowDefaultCombinationOption();
    $('input[name="changeProductName"]').trigger('change');
    $('input[name="enabledControllers[Category]"]').trigger('change');

    $('select[name="selectedGroups[]"]').selectize({
        plugins: ['drag_drop', 'remove_button'],
        delimiter: ',',
        persist: false,
        onChange: function(value) {
            addPositionToSelectizeItems(this);
        },
        onInitialize: function() {
            addPositionToSelectizeItems(this);
        }
    });
});

function addPositionToSelectizeItems(selectizeItem) {
    let originalOptions = selectizeItem.options;
    $('div.item', selectizeItem.$control).each(function(index, item) {
        let originalOption = originalOptions[$(this).data('value')];
        let currentPosition = (index + 1);
        let itemLinks = $('a', item).detach();
        $(item).html(currentPosition + '.&nbsp;' + originalOption.text);
        $(item).append(itemLinks);
    });
}

function handleChangeProductNameOption() {
    $(document).on('change', 'input[name="changeProductName"]', function() {
        if ($('input[name="changeProductName"]:checked').val() == "1") {
            $('.nameSeparatorFormGroup').show();
        } else {
            $('.nameSeparatorFormGroup').hide();
        }
    });
}

function handleCategoryRestrictionOption() {
    $(document).on('change', 'input[name="enabledControllers[Category]"]', function() {
        if ($('input[name="enabledControllers[Category]"]:checked').val() == "1") {
            $('.form-categoryRestrictions').show();
        } else {
            $('.form-categoryRestrictions').hide();
        }
    });
}

function handleSelectedGroupOption() {
    let val = $('select[name="selectedGroups[]"]').val();

    if (typeof(val) == 'undefined' || val == null || !val.length) {
        document.querySelectorAll('#settings.tab-pane > .form-group:not(:first-child)').forEach(function(formGroup) {
            formGroup.classList.add('hide');
        });
        document.querySelectorAll('.nav-tabs a[href="#performance"], .nav-tabs a[href="#restrictions"], .nav-tabs a[href="#maintenance"], .nav-tabs a[href="#cron"]').forEach(function(tabPaneLink) {
            tabPaneLink.parentNode.classList.add('hide');
        });
    } else {
        document.querySelectorAll('#settings.tab-pane > .form-group:not(:first-child)').forEach(function(formGroup) {
            formGroup.classList.remove('hide');
        });
        document.querySelectorAll('.nav-tabs a[href="#performance"], .nav-tabs a[href="#restrictions"], .nav-tabs a[href="#maintenance"], .nav-tabs a[href="#cron"]').forEach(function(tabPaneLink) {
            tabPaneLink.parentNode.classList.remove('hide');
        });
        if (typeof colorGroups !== 'undefined') {
            display_hide_squares_color();
        }
    }
}

function handleShowDefaultCombinationOption() {
    const checked = document.querySelector('#hideCombinationsWithoutStock_on').checked;

    if (!checked) {
        $('.showDefaultCombinationIfOos').hide();
    } else {
        $('.showDefaultCombinationIfOos').show();
    }

    $(document).on('change', 'input[name="hideCombinationsWithoutStock"]:checked', function() {
        if ($(this).val() == 1) {
            $('.showDefaultCombinationIfOos').show();
        } else {
            $('.showDefaultCombinationIfOos').hide();
        }
    });
}

function display_hide_squares_color() {
    let selectedGroups = $('select[name="selectedGroups[]"]').val();
    let hasSelectedColorGroup = false;
    for (var i = selectedGroups.length - 1; i >= 0; i--) {
        if ($.inArray(parseInt(selectedGroups[i]), colorGroups) != -1) {
            hasSelectedColorGroup = true;
            break;
        }
    }

    if (hasSelectedColorGroup) {
        $('.colorSquaresFormGroup').show();
    } else {
        $('.colorSquaresFormGroup').hide();

        $('#hideColorSquares_on').prop('checked', false);
        $('#hideColorSquares_off').prop('checked', true);
    }
}
