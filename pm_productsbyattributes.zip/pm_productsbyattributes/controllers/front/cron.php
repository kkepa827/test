<?php
/**
 * @author Presta-Module.com <support@presta-module.com>
 * @copyright Presta-Module
 * @license   see file: LICENSE.txt
 *
 *           ____     __  __
 *          |  _ \   |  \/  |
 *          | |_) |  | |\/| |
 *          |  __/   | |  | |
 *          |_|      |_|  |_|
 *
 ****/

if (!defined('_PS_VERSION_')) {
    exit;
}
class pm_productsbyattributescronModuleFrontController extends ModuleFrontController
{
    public function init()
    {
        if (ob_get_length() > 0) {
            ob_clean();
        }
        header('X-Robots-Tag: noindex, nofollow', true);
        header('Content-type: application/json');
        $secureKey = Configuration::getGlobalValue('PM_SPA_SECURE_KEY');
        if (empty($secureKey) || $secureKey !== Tools::getValue('secure_key')) {
            Tools::redirect('404');
            die;
        }
        // die(json_encode([
        //     'result' => (bool)$this->module->fillCacheTable(),
        // ]));
    }
}
